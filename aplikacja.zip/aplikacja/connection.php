<?php

    $host = "localhost";
    $user = "polszowy";
    $pass = "aK2zoweimoo6";
    $data_base = "polszowy_model";

?>